# ApiV2010CallEvent

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Request** | Pointer to **interface{}** | Contains a dictionary representing the request of the call. |
**Response** | Pointer to **interface{}** | Contains a dictionary representing the call response, including a list of the call events. |

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


