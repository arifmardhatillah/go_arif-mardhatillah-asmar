// Package config for config files.
package client

// LibraryVersion specifies the current version of twilio-go.
const LibraryVersion = "1.7.1"
