# ListQueueResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Queues** | [**[]ApiV2010Queue**](ApiV2010Queue.md) |  |[optional] 
**End** | **int** |  |[optional] 
**FirstPageUri** | **string** |  |[optional] 
**NextPageUri** | Pointer to **string** |  |
**Page** | **int** |  |[optional] 
**PageSize** | **int** |  |[optional] 
**PreviousPageUri** | Pointer to **string** |  |
**Start** | **int** |  |[optional] 
**Uri** | **string** |  |[optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


