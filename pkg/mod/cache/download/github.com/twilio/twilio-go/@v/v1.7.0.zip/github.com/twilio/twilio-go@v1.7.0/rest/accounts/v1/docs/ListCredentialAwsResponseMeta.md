# ListCredentialAwsResponseMeta

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstPageUrl** | **string** |  |[optional] 
**NextPageUrl** | Pointer to **string** |  |
**Page** | **int** |  |[optional] 
**PageSize** | **int** |  |[optional] 
**PreviousPageUrl** | Pointer to **string** |  |
**Url** | **string** |  |[optional] 
**Key** | **string** |  |[optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


